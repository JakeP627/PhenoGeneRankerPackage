## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(PhenoGeneRankerPackage)

## -----------------------------------------------------------------------------
library(PhenoGeneRankerPackage)

## ----eval=FALSE---------------------------------------------------------------
#  walkMatrix <-CreateWalkMatrix('file.txt')

## ----eval=FALSE---------------------------------------------------------------
#  rwr<-RandomWalkRestarts(walkMatrix, c('gene1', 'gene2'), c(), TRUE)

## ----eval=FALSE---------------------------------------------------------------
#  walkMatrix <-CreateWalkMatrix('file.txt')
#  rwr <-RandomWalkRestarts(walkMatrix, c('gene1', 'gene2'), c(), TRUE)

